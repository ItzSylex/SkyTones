import os
import shutil

directory = "./"  # Adjust if needed

base_tab_files = [
    "tab_bottom_selected.png",
    "tab_bottom_unselected.png",
    "tab_top_selected.png",
    "tab_top_unselected.png"
]

for base in base_tab_files:
    base_path = os.path.join(directory, base)

    if not os.path.isfile(base_path):
        print(f"Missing: {base}, skipping.")
        continue

    name, ext = os.path.splitext(base)

    for i in range(1, 8):
        new_name = f"{name}_{i}{ext}"
        new_path = os.path.join(directory, new_name)

        if os.path.exists(new_path):
            print(f"Skipping (already exists): {new_name}")
        else:
            shutil.copy(base_path, new_path)
            print(f"Created: {new_name}")
